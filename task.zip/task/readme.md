I am using following technologies to delevelop task application:
PHP 5.6 (should enable pdo driver)
Sqlite3
Bootstrap (HTML Framework)

Working flow:
User can able to create new task to fill form manatory fields.After user fill manatory fields it will call the jquery ajax function and will save into the database,added task will display into tasks list.
User can able to view the list of tasks and click edit button to edit the particular task, after click edit corresponding task data will fill into form fields,user can able to edit the corresponding task.
Task list user can able to delete the particular task and click delete button to delete the particular task,after delete the particular task, task status will change into backup.
